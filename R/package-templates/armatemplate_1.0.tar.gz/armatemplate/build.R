
devtools::install()

devtools::build()
  
myPackage <- devtools::as.package("armatemplate")

devtools::document()
